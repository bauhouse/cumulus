<?php

	Interface Singleton{
		public static function instance();
	}

